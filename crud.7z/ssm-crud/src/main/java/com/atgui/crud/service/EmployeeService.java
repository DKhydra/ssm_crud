package com.atgui.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atgui.crud.bean.Employee;
import com.atgui.crud.bean.EmployeeExample;
import com.atgui.crud.bean.EmployeeExample.Criteria;
import com.atgui.crud.dao.EmployeeMapper;

@Service
public class EmployeeService {
	@Autowired
	EmployeeMapper employeeMapper;
	/**
	 * ��ѯ����Ա��
	 * @return
	 */
	public List<Employee> getAll() {
		System.out.println("employeeMapper: "+employeeMapper);
		List<Employee> emps=employeeMapper.selectByExampleWithDept(null);
		return emps;
	}
	/**
	 * Ա�����淽��
	 * @param employee
	 */
	public void saveEmp(Employee employee) {
		// TODO Auto-generated method stub
		employeeMapper.insertSelective(employee);
	}
	
	/**
	 * �����û����Ƿ����
	 * @param empName
	 * @return true :����; false:������
	 */
	public boolean checkUser(String empName) {
		EmployeeExample example=new EmployeeExample();
		Criteria criteria= example.createCriteria();
		criteria.andEmpNameEqualTo(empName);
		long count=employeeMapper.countByExample(example);
		return count==0;
	}

}
