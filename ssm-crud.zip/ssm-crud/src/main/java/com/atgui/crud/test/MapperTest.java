package com.atgui.crud.test;

import java.util.UUID;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.atgui.crud.bean.Department;
import com.atgui.crud.bean.Employee;
import com.atgui.crud.dao.DepartmentMapper;
import com.atgui.crud.dao.EmployeeMapper;

/**
 * ����dao���
 * @author Administrator
 * ����springTest ģ��
 *@ContextConfigurationָ��spring�����ļ���λ��
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:applicationContext.xml"})
public class MapperTest {
	@Autowired
	DepartmentMapper departmentMapper;
	
	@Autowired
	EmployeeMapper employeeMapper;
	
	@Autowired
	SqlSession sqlSession;
	/**
	 * ����dept mapper
	 */
	@Test
	public void testCRUD(){
		System.out.println(departmentMapper);
		//1.���뼸������
//		departmentMapper.insertSelective(new Department("������"));
//		departmentMapper.insertSelective(new Department("���Բ�"));
	
		//2.����Ա������
		//employeeMapper.insertSelective(new Employee(null, "Jerry", "M", "jerry@aa.com", 1));
		//employeeMapper.insertSelective(new Employee(null, "Jerry", "M", "jerry@aa.com", 1));
	
		//3.����������Ա�� ִ������������sqlSession
		/*for (int i = 0; i < array.length; i++) {
			employeeMapper.insertSelective(new Employee(null, "Jerry", "M", "jerry@aa.com", 1));
		}*/
		EmployeeMapper mapper=sqlSession.getMapper(EmployeeMapper.class);
		for (int i = 0; i <1000; i++) {
			String name=UUID.randomUUID().toString().substring(0, 5)+i;
			mapper.insert(new Employee(null, name, "M", name+"@aa.com", 1));
		}
		System.out.println("�������");
	}

}
